﻿# Changelog

## 0.1.0 - 2026-03-11

### Added

- Dock 化配置界面与工具 profile 管理
- 75 个顶层 MCP 工具
- TileSet 最小闭环：`create_empty`、`assign_to_tilemap`
- 调试事件缓冲区
- `debug_log.get_recent`
- `debug_log.get_errors`
- `debug_log.clear_buffer`
- `debug_profiler.get_summary`
- 安装与发布文档
- zip 发布包

### Changed

- `scene_management.create` 改为使用受控临时场景目录
- `scene_management.save_as` 成功后会切换当前场景路径
- 资源类型过滤改为继承感知匹配
- `script_edit_gd.add_function` 的 `return_type` 改为真正可选
- README 改写为面向开源使用者的安装与快速开始入口
- 仓库远程地址统一收口为 `godot-dotnet-mcp`

### Fixed

- `localization_service.gd` 写只读字典导致的启动风险
- `create -> save_as -> get_current` 路径不同步
- `Texture2D` 派生类型枚举漏项
- TileSet 创建后立即赋值失败的控制流问题

### Known Limitations

- 当前调试回读仍基于插件缓冲区，不是直接读取 Godot 原生 Output / Debugger 面板
- 节点 `/root/...` 路径兼容补丁已落地，但仍待插件重载后的最终黑盒确认
