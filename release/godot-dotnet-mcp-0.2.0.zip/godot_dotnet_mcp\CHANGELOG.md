﻿# Changelog

## 0.2.0 - 2026-03-11

### Changed

- 对外版本号统一为 `0.2.0`，与 `plugin.cfg`、MCP `initialize` 返回值和发布包命名保持一致
- 发布文档、README 下载链接与安装发布说明统一切换到 `godot-dotnet-mcp-0.2.0.zip`

### Fixed

- `debug_runtime_bridge` 在主项目停止后可稳定回读 `session_started`、`session_stopped` 与最近生命周期事件
- 运行时桥接 fallback 事件持久化与事件时间序合并逻辑修正，避免停止阶段事件在最近事件列表中被错误顶掉

### Validation

- 发布前全量回归测试结论更新为 `通过`
- 最终打包前确认基于 `v0.2 == v0.2.0` 口径执行
- 发布包继续排除 `agent_workflow/` 与内部测试目录

## 0.1.0 - 2026-03-11

### Added

- 首个正式对外发布版本
- Dock 化配置界面与工具 profile 管理
- 75 个顶层 MCP 工具
- 场景、节点、资源、脚本、动画、材质、TileMap、导航、物理、音频、UI 等能力域
- Godot.NET / C# 场景绑定分析与导出成员审计
- TileSet 最小闭环：`create_empty`、`assign_to_tilemap`
- 调试事件缓冲区
- `debug_log.get_recent`
- `debug_log.get_errors`
- `debug_log.clear_buffer`
- `debug_profiler.get_summary`
- 受控临时场景目录与场景保存链路收口
- 继承感知的资源类型过滤
- 安装与发布文档
- zip 发布包

### Known Limitations

- 当前主项目调试回读已支持运行时桥接事件和编辑器调试会话状态，但仍不是直接读取 Godot 原生 Output / Debugger 面板的全文镜像
- 若 `MCPRuntimeBridge` 同名 Autoload 被其它脚本占用，运行时桥接不会覆盖原设置，而是返回未接入状态
- 节点 `/root/...` 路径兼容补丁已落地，但仍待插件重载后的最终黑盒确认
